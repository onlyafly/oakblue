package ast

import (
	"testing"

	"github.com/onlyafly/oakblue/internal/spec"
	"github.com/stretchr/testify/assert"
)

func TestProgram_String_OneStatement(t *testing.T) {
	p := Program([]Statement{
		&InstructionStatement{
			OpCode: spec.OP_ADD,
			Dr:     NewRegister("R0"),
			Sr1:    NewRegister("R0"),
			Mode:   1,
			Imm5:   NewInteger(1),
		},
	})

	expected := "ADD R0 R0 1"
	actual := p.String()

	assert.Equal(t, expected, actual)
}

func TestProgram_String_MultipleStatements(t *testing.T) {
	p := Program([]*Statement{
		NewStatement([]Node{
			NewSymbol("ADD"),
			NewSymbol("R0"),
			NewSymbol("R0"),
			NewInteger(1),
		}),
		NewStatement([]Node{
			NewSymbol("ADD"),
			NewSymbol("R0"),
			NewSymbol("R0"),
			NewInteger(1),
		}),
		NewStatement([]Node{
			NewSymbol("ADD"),
			NewSymbol("R0"),
			NewSymbol("R0"),
			NewInteger(1),
		}),
	})

	expected := "ADD R0 R0 1\nADD R0 R0 1\nADD R0 R0 1"
	actual := p.String()

	assert.Equal(t, expected, actual)
}
